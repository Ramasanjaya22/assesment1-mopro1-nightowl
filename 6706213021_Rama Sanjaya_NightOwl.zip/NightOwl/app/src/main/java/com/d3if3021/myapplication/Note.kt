package com.d3if3021.myapplication

import java.io.Serializable

class Note(val mood: String, val activity: String, val food: String, val note: String) : Serializable

